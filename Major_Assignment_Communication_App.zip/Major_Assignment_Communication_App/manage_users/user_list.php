<?php
    include "../common_functions/check_active_session.php";
    checkActiveSession()
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../style.css">
    <title>Users List</title>
</head>
<body>
    <div class="appContainer usersList">
        <div class="navigationBar">
            <?php
                require "../navigation/navigation.php"
            ?>
        </div>
        <h2 class="display-2">Users</h2>
        <div class="tableWrapper">
            <table class="table">
                <tr>
                    <th>ID</th>
                    <th>User Name</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
                <?php
                    include "../common_functions/db_connection_helper.php";
                    $db = dbConnection();
                    $query = "SELECT id, username, email FROM users";
                    $result = $db->query($query);
                    $num_results = $result->num_rows;
                    if ($num_results > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row["id"] . "</td>";
                            echo "<td>" . $row["username"] . "</td>";
                            echo "<td>" . $row["email"] . "</td>";
                            echo "<td><a href='./edit_user.php?email=" . $row["email"] . "&username=" . $row["username"] . "&id=" . $row["id"] ."'>Edit</a> | <a href='./confirm_delete.php?id=" . $row["id"] . "'>Delete</a></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "0 results";
                    }

                    $db->close();
                ?>
            </table>
        </div>
    </div>
</body>
</html>