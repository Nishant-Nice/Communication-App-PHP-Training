<?php
    include "../common_functions/check_active_session.php";
    checkActiveSession()
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../style.css">
    <title>Confirm Delete</title>
</head>
<body>
    <div class="appContainer deleteUser">
        <div class="navigationBar">
            <?php
                require "../navigation/navigation.php"
            ?>
        </div>
        <h2 class="display-2">Confirm User Deletion</h2>
        <h3 class="display-3">Are you Sure?</h3>
        <div class="cnfDelete"> 
            <?php
                if(isset($_GET['id'])) {
                    $id = $_GET['id'];
                    echo "<a class='btn btn-primary' href='./check_delete.php?id=" . $id . "'>Delete</a>";
                    echo "<a class='btn btn-primary' href='./user_list.php'>Cancel</a>";
                } else {
                    echo "Error: Email parameter not set.";
                }
            ?>
            
        </div>
    </div>
</body>
</html>