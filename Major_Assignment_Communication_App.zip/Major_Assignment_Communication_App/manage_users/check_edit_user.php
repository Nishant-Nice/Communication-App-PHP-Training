<?php
    include "../common_functions/db_connection_helper.php";
    
    $db = dbConnection();

    $username = $_POST["username"];
    $email = $_POST["email"];
    $id = $_POST["id"];

    if (!isset($username) && !isset($email)) {
        echo '<p>You have not entered all required details. Please go back and try again.</p>';
        session_destroy();
        exit;
    }

    $query = "UPDATE users SET username = '$username', email = '$email' WHERE id = '$id'";
    $result = $db->query($query);
    header("location:user_list.php");
    $db->close();
?>

    