<?php
    include "../common_functions/db_connection_helper.php";
    
    $db = dbConnection();
    
    $id = $_GET['id'];
    $query = "DELETE FROM users WHERE id='$id';";
    $result = $db->query($query);
    header("location:user_list.php");
    $db->close();
?>

    