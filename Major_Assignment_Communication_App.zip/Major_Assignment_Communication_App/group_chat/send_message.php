<?php
    include "../common_functions/db_connection_helper.php";
    
    $db = dbConnection();

    $message = $_POST["message"];
    $username = $_POST["username"];

    if (!isset($message)) {
        echo '<p>You have not entered all required details. Please go back and try again.</p>';
        session_destroy();
        exit;
    }

    $query = "INSERT INTO chats (id, time, username, message) VALUES(NULL, NOW(), '$username', '$message')";
    $result = $db->query($query);
    header("location:group_chat.php");
    $db->close();
?>

    