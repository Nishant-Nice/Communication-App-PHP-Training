<?php
    include "../common_functions/check_active_session.php";
    checkActiveSession()
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../style.css">
    <title>Group Chat</title>
</head>
<body>
    <div class="appContainer groupChat">
        <div class="navigationBar">
            <?php
                require "../navigation/navigation.php"
            ?>
        </div>
        <h2 class="display-2">Chat Group</h2>
        <div class="chatWrapper">
            <ul class='list-group'>
                <?php
                    include "../common_functions/db_connection_helper.php";
                    $db = dbConnection();
                    $query = "SELECT time, username, message FROM chats";
                    $result = $db->query($query);
                    $num_results = $result->num_rows;
                    if ($num_results > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<li class='list-group-item'>" . "<span class='messageSpans'>[" . $row["time"] . "]</span>" . "<span class='messageSpans'>" . $row["username"] . ":</span>" . "<span class='messageSpans'>" . $row["message"] . "</span>" . "</li>";
                        }
                    } else {
                        echo "0 results";
                    }
                ?>
            </ul>
            <form action="./send_message.php" method="POST">
                <div class="formRow">
                    <label class="form-label formColumn">
                        <?php
                            $email = $_SESSION['email'];
                            $query = "SELECT username FROM users where email = '$email'";
                            $result = $db->query($query);
                            $num_results = $result->num_rows;
                            if ($num_results > 0) {
                                while($row = $result->fetch_assoc()) {
                                    echo "<span>" . $row['username'] . "</span>";
                                    echo "<input type='hidden' value='$row[username]' name='username' />";
                                }
                            } else {
                                echo "0 results";
                            }
                        ?>
                    </label>
                    <div class="formColumn messageSendBtnWrapper">
                        <input class="form-control" type="textarea" name="message">
                        <input class="btn btn-primary" type="submit" value="Send Message">
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>
</html> 