<?php
    include "../common_functions/db_connection_helper.php";

    session_start();
    $db = dbConnection();

    $email = $_POST["email"];
    $password = $_POST["password"];

    if (!isset($email) || !isset($password)) {
        echo '<p>You have not entered all required details. Please go back and try again.</p>';
        session_destroy();
        exit;
    }

    $email = stripslashes($email);
    $password = stripslashes($password);

    $query = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
    $result = $db->query($query);
    $num_results = $result->num_rows;
    
    if ($num_results == 1) {
        $_SESSION["email"] = $email;
        header("location:../group_chat/group_chat.php"); // header function, redirect to group chat page
    } else {
        echo "Wrong Email or Password";
        session_destroy();
    }
    $db->close();
?>

    