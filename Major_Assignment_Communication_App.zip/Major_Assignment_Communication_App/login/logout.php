<?php
    session_start();
    session_destroy();
?>

<html>

<head></head>

<body>
    <h1>Logout Successful</h1>
    <a href="login.php">Click here for login again</a>
</body>

</html>