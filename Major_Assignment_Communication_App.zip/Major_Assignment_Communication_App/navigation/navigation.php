<nav class="navbar bg-primary">
    <div class="container-fluid">
        <ul class="nav navbar-nav">
            <li><a href="../group_chat/group_chat.php">Group Chat</a></li>
            <li><a href="../manage_users/user_list.php">Manage Users</a></li>
            <li><a href="../manage_documents/document_list.php">Manage Document</a></li>
            <li><a href="../login/logout.php">Logout</a></li>
        </ul>
    </div>
</nav>