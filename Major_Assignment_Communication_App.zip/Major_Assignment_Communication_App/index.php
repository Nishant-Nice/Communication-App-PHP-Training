<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="./style.css">
    <title>Welcome</title>
</head>
<body>
    <div class="appContainer welcome">
        <h1 class="display-1">Welcome to Users Module</h1>
        <div class="welcomeButtons">
            <h3 class="display-3">Existing Users</h3>
            <a class="btn btn-primary" href="./login/login.php">Login</a>
            <h3 class="display-3">New User</h3>
            <a class="btn btn-primary" href="./register/register.php">Register</a>
        </div>
    </div> 
</body>
</html>