<?php
    include "../common_functions/db_connection_helper.php";
    
    $db = dbConnection();
    
    $uploadId = $_GET['uploadId'];
    $query = "DELETE FROM uploads WHERE uploadId='$uploadId';";
    $result = $db->query($query);
    header("location:document_list.php");
    $db->close();
?>

    