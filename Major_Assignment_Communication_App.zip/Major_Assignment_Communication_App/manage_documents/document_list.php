<?php
    include "../common_functions/check_active_session.php";
    checkActiveSession()
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../style.css">
    <title>Documents List</title>
</head>
<body>
    <div class="appContainer usersList documentsList">
        <div class="navigationBar">
            <?php
                require "../navigation/navigation.php"
            ?>
        </div>
        <h2 class="display-2">My Uploads</h2>
        <div class="tableWrapper">
            <table class="table">
                <tr>
                    <th>ID</th>
                    <th>Description</th>
                    <th>File Name</th>
                    <th>Action</th>
                </tr>
                <?php
                    @$db = new mysqli('localhost', 'root', '', 'dashboard', 3306);
                    if (!$db) {
                        echo "Failed to connect to MySQL: " . $db->connect_error;
                        exit();
                    }
                    $query = "SELECT uploadId, description, filename FROM uploads";
                    $result = $db->query($query);
                    $num_results = $result->num_rows;
                    if ($num_results > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row["uploadId"] . "</td>";
                            echo "<td>" . $row["description"] . "</td>";
                            echo "<td>" . $row["filename"] . "</td>";
                            echo "<td><a href='./edit_document.php?description=" . $row["description"] . "&filename=" . $row["filename"] . "&uploadId=" . $row["uploadId"] . "'>Edit</a> | <a href='./confirm_delete.php?uploadId=" . $row["uploadId"] . "'>Delete</a></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "0 results";
                    }

                    $db->close();
                ?>
            </table>
        </div>

        <form class="uploadForm" action="uploads.php" method="post" enctype="multipart/form-data">
            <h3 class="display-3">Shared Uploads</h3>
            <div class="formRow">
                <div class="formColumn">
                    File Description
                </div>
                <div class="formColumn">
                    <input type="text" name="fileDescription">
                </div>
            </div>
            <div class="formColumn">
                <input type="hidden" name="MAX_FILE_SIZE" value="10000000">
                <input class="fileInput" type="file" name="userfile">
                <input type="submit" value="Upload File">
            </div>
        </form>
    </div>
</body>
</html>

<!-- ALTER TABLE uploads AUTO_INCREMENT = 1; -->