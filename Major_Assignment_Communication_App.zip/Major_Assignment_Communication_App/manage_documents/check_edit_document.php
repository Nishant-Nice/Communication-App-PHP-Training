<?php
    include "../common_functions/db_connection_helper.php";
    
    $db = dbConnection();

    $description = $_POST["description"];
    $filename = $_POST["filename"];
    $uploadId = $_POST["uploadId"];
    echo $uploadId;
    if (!isset($description) && !isset($filename)) {
        echo '<p>You have not entered all required details. Please go back and try again.</p>';
        session_destroy();
        exit;
    }

    $query = "UPDATE uploads SET description = '$description', filename = '$filename' WHERE uploadid = '$uploadId'";
    $result = $db->query($query);
    header("location:document_list.php");
    $db->close();
?>

    