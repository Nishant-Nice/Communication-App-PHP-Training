<?php
    include "../common_functions/check_active_session.php";
    checkActiveSession()
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../style.css">
    <title>Edit Document</title>
</head>
<body>
    <div class="appContainer editUser">
        <div class="navigationBar">
            <?php
                require "../navigation/navigation.php"
            ?>
        </div>
        <h2 class="display-2">Edit Document</h2>
        <form action="check_edit_document.php" method="POST">
            <div class="formRow">
                <label class="form-label formColumn">
                    Description
                </label>
                <div class="formColumn">
                    <?php
                        if(isset($_GET['description'])) {
                            $description = $_GET['description'];
                            echo "<input class='form-control' type='text' name='description' value='$description'>";
                        } else {
                            echo "Error: description parameter not set.";
                        }
                    ?>
                </div>
            </div>
            <div class="formRow">
                <label class="form-label formColumn">
                    File Name
                </label>
                <div class="formColumn">
                    <?php
                        if(isset($_GET['filename'])) {
                            $filename = $_GET['filename'];
                            echo "<input class='form-control' type='text' name='filename' value='$filename'>";
                        } else {
                            echo "Error: filename parameter not set.";
                        }
                    ?>
                </div>
            </div>
            <?php
                if(isset($_GET['uploadId'])) {
                    $uploadId = $_GET['uploadId'];
                    echo "<input class='form-control' type='hidden' name='uploadId' value='$uploadId'>";
                } else {
                    echo "Error: uploadId parameter not set.";
                }
            ?>
            <div class="cnfDelete"> 
                <input class="btn btn-primary submitBtn" type="submit" value="Edit">
                <a class="btn btn-primary" href="./document_list.php">Cancel</a>
            </div>
    
        </form>
    </div>
</body>
</html>