<?php
    if ($_FILES['userfile']['error'] > 0) {
        switch ($_FILES['userfile']['error']) {
            case 1:
                echo "File exceeded upload_max_file_size";
                break;

            case 2:
                echo "File exceeded upload max_file_size";
                break;

            case 3:
                echo "File only partially uploaded";
                break;

            case 4:
                echo "no file uploaded";
                break;
        }
    }
    $fileDescription = $_POST["fileDescription"];

    $document_path = $_SERVER['DOCUMENT_ROOT'];
    $upload_file_path = $document_path . "/PHP/Major_Assignment_Communication_App/manage_documents/uploads/" . $_FILES['userfile']['name'];

    if (is_uploaded_file($_FILES['userfile']['tmp_name'])) {
        if (!move_uploaded_file($_FILES['userfile']['tmp_name'], $upload_file_path)) {
            echo "Problem: Could not move file to destination directory";
            exit;
        }
    } else {
        echo "Problem: Possible file upload attack. Filename:";
        echo $_FILES['userfile']['name'];
        exit;
    }

    $db = new mysqli('localhost', 'root', '', 'dashboard', 3306);

    if (mysqli_connect_errno()) {
        echo '<p>Error: Could not connect to the database <br> Please try again later </p>';
        exit;
    }

    $null = NULL;
    $query = "INSERT INTO uploads VALUES (?, ?, ?)";
    $stmt = $db->prepare($query);
    $stmt->bind_param('iss', $null, $fileDescription, $_FILES['userfile']['name']);
    $stmt->execute();


    $db->close();   

    header("location:document_list.php");
?>