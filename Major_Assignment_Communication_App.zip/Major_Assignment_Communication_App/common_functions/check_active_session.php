<?php
    function checkActiveSession() {
        session_start();
        if (!$_SESSION['email']) {
            header("location:../login/login.php");
        }
    }
?>