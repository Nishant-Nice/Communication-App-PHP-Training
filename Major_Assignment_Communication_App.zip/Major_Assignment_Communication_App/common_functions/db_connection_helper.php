<?php
    function dbConnection() {
        @$dbConnection = new mysqli('localhost', 'root', '', 'dashboard', 3306);
        if (!$dbConnection) {
            echo "Failed to connect to MySQL: " . $dbConnection->connect_error;
            exit();
        }
        return $dbConnection;
    }  
?>
