<?php
    $name = $_POST["name"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $cnfPassword = $_POST["cnfPassword"];

    if (!isset($name) || !isset($email) || !isset($password) || !isset($cnfPassword)) {
        echo '<p>You have not entered all required details. Please go back and try again.</p>';
        exit;
    }

    $db = new mysqli('localhost', 'root', '', 'dashboard', 3306);
    if(!$db) {
        echo "<p>Something went wrong!</p>";
    }
    $null = NULL;
    $query = "INSERT INTO users VALUES (?, ?, ?, ?)";
    $stmt = $db->prepare($query);
    $stmt->bind_param('isss', $null, $name, $email, $password);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        header("location:./register_success.php");
    } else {
        echo "<p>An erro has occurred.</p>";
    }

    $db->close();
?>