<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../style.css">
    <title>Register</title>
</head>
<body>
    <div class="appContainer register">
        <h2 class="display-2">Register</h2>
        <form action="./check_register.php" method="POST">
            <div class="formRow">
                <label class="form-label formColumn">
                    Full Name
                </label>
                <div class="formColumn">
                    <input class="form-control" type="text" name="name">
                </div>
            </div>
            <div class="formRow">
                <label class="form-label formColumn">
                    Email
                </label>
                <div class="formColumn">
                    <input class="form-control" type="text" name="email">
                </div>
            </div>
            <div class="formRow">
                <label class="form-label formColumn">
                    Password
                </label>
                <div class="formColumn">
                    <input class="form-control" type="text" name="password">
                </div>
            </div>
            <div class="formRow">
                <label class="form-label formColumn">
                    Confirm Password
                </label>
                <div class="formColumn">
                    <input class="form-control" type="text" name="cnfPassword">
                </div>
            </div>
            <input class="btn btn-primary submitBtn" type="submit" value="Register User">
        </form>
    </div>
</body>
</html>